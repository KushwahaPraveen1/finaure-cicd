const express = require('express');
const axios = require('axios');
const cors = require('cors'); // Import cors
const app = express();
const port = 8000; // You can choose your desired port

// Set up middleware for parsing JSON
app.use(express.json());

// Use CORS middleware
app.use(cors()); // Enable CORS for all routes

// Middleware function to call external API
const callExternalAPI = async (route, queryParams = '') => {
  const baseUrl = 'https://dev.indianapi.in'; // Replace with the actual external API base URL

  try {
    const response = await axios.get(`${baseUrl}${route}${queryParams}`, {
      headers: {
        'X-API-Key': 'sk-live-rEDmk45gSS3bqMlq6plYFnKtFqPUIseLDPL9nvy8', // Replace with the actual API key
      },
    });
    return response.data; // Return the data you get from the external API
  } catch (error) {
    console.error('Error calling external API:', error);
  }
};
const callExternalAPIPOST = async (route, queryParams = '') => {
  const baseUrl = 'https://dev.indianapi.in'; // Replace with the actual external API base URL

  try {
    const response = await axios.post(`${baseUrl}${route}${queryParams}`, null, {
      headers: {
        'X-API-Key': 'sk-live-rEDmk45gSS3bqMlq6plYFnKtFqPUIseLDPL9nvy8', // Replace with the actual API key
      },
    });
    return response.data; // Return the data you get from the external API
  } catch (error) {
    console.error('Error calling external API:', error.message);
    throw error;
  }
};

// Route for handling requests to the backend API
app.get('/api/stock', async (req, res) => {
  const stockName = req.query.name; // Get query parameters from the frontend request
  const queryParams = stockName ? `?name=${stockName}` : ''; // Construct query params
  
  try {
    const data = await callExternalAPI('/stock', queryParams);
    res.json(data); // Send the data back to the frontend
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch data from external API' });
  }
});

app.get('/api/logo', async (req, res) => {
  const stockName = req.query.stock_name; // Get query parameters from the frontend request
  const queryParams = stockName ? `?stock_name=${encodeURIComponent(stockName)}` : ''; // URL encode stock name
// console.log(queryParams);
try {
  const data = await callExternalAPI('/logo', queryParams);
  res.json(data); // Send the data back to the frontend
} catch (error) {
  res.status(500).json({ error: 'Failed to fetch data from external API' });
}
});
app.get('/api/logo_mutual_fund', async (req, res) => {
  const stockName = req.query.mutual_fund; // Get query parameters from the frontend request
  const queryParams = stockName ? `?mutual_fund=${encodeURIComponent(stockName)}` : ''; // URL encode stock name
// console.log(queryParams);
try {
  const data = await callExternalAPI('/logo', queryParams);
  res.json(data); // Send the data back to the frontend
} catch (error) {
  res.status(500).json({ error: 'Failed to fetch data from external API' });
}
});



app.post('/api/chart', async (req, res) => {
  const stockId = req.query.stock_id; // Get stock_id from the query parameters
  const queryParams = stockId ? `?stock_id=${encodeURIComponent(stockId)}` : ''; // Construct query params

  try {
    const data = await callExternalAPIPOST(`/1D_intraday_data${queryParams}`);
    res.json(data); // Send the data back to the frontend
  } catch (error) {
    console.error("Error fetching data from external API:", error); // Log the error for debugging
    res.status(500).json({ error: 'Failed to fetch data from external API' });
  }
});






app.get('/api/trending', async (req, res) => {
  try {
    const data = await callExternalAPI('/trending');
    res.json(data); // Send the data back to the frontend
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch data from external API' });
  }
});
app.get('/api/week_high_low', async (req, res) => {
  try {
    const data = await callExternalAPI('/fetch_52_week_high_low_data');
    res.json(data); // Send the data back to the frontend
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch data from external API' });
  }
});

app.get('/api/mutual_funds', async (req, res) => {
  try {
    const data = await callExternalAPI('/mutual_funds');
    res.json(data); // Send the data back to the frontend
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch data from external API' });
  }
});

app.get('/api/indices', async (req, res) => {
  try {
    const data = await callExternalAPI('/static/all_stocks.json');
    res.json(data); // Send the data back to the frontend
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch data from external API' });
  }
});
app.get('/api/stock_id', async (req, res) => {
  try {
    const data = await callExternalAPI('/static/all_stocks.json');
    res.json(data); // Send the data back to the frontend
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch data from external API' });
  }
});

const thirdPartyApiUrl = 'https://dev.indianapi.in/static/all_stocks.json';

app.get('/api/search', async (req, res) => {
  const { term } = req.query;
  try {
    // Fetch data from the third-party API
    const response = await axios.get(thirdPartyApiUrl);
    const data = response.data;

    // Filter data based on the search term
    const searchResults = data.filter((stock) =>
      stock.name.toLowerCase().includes(term.toLowerCase())
    ).slice(0, 50); // Limit results to 50 for performance

    res.json(searchResults);
  } catch (error) {
    console.error('Error fetching search results:', error);
    res.status(500).json({ error: 'Failed to fetch data from the third-party API' });
  }
});

//Stock Search

app.get('/api/stock_search', async (req, res) => {
  const stockName = req.query.query; // Get query parameters from the frontend request
  const queryParams = stockName ? `?query=${stockName}` : ''; // Construct query params
  
  try {
    const data = await callExternalAPI('/industry_search', queryParams);
    res.json(data); // Send the data back to the frontend
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch data from external API' });
  }
});
app.get('/api/mutual_search', async (req, res) => {
  const stockName = req.query.query; // Get query parameters from the frontend request
  const queryParams = stockName ? `?query=${stockName}` : ''; // Construct query params
  
  try {
    const data = await callExternalAPI('/mutual_fund_search', queryParams);
    res.json(data); // Send the data back to the frontend
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch data from external API' });
  }
});

app.get('/api/mutual_fund', async (req, res) => {
  const stockName = req.query.stock_name; // Get query parameters from the frontend request
  const queryParams = stockName ? `?stock_name=${stockName}` : ''; // Construct query params
  
  try {
    const data = await callExternalAPI('/mutual_funds_details', queryParams);
    res.json(data); // Send the data back to the frontend
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch data from external API' });
  }
});


// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
